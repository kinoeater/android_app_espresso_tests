package com.mytaxi.android_demo;


import com.mytaxi.android_demo.activities.MainActivity;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import androidx.test.espresso.action.ViewActions;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.CoreMatchers.anything;

@RunWith(AndroidJUnit4.class)
//@LargeTest


public class logged_in_test {



    @Rule
    public ActivityTestRule<MainActivity> mActivityRule =
            new ActivityTestRule<>(MainActivity.class);



    @Test
    public void play_around()throws Exception  {
        Thread.sleep(5000);
        onView(withId(R.id.edt_username)).perform(typeText("crazydog335"),
                closeSoftKeyboard());
        onView(withId(R.id.edt_password)).perform(typeText("venture"),
                closeSoftKeyboard());
        onView(withId(R.id.btn_login)).perform(ViewActions.click());

        //onView(withId(R.id.textSearch)).perform(ViewActions.click());
       // onView(withId(R.id.textSearch)).perform(typeText("sa"));
      //  onView(withId(R.id.textSearch)).perform(typeText("sa"));
       // onView(withId(R.id.textSearch)).perform(click());
       // onView(isAssignableFrom(AutoCompleteTextView.class)).perform(typeText("sa"),
       //         closeSoftKeyboard());

     //   onView(withText("Sarah Scott"))
       //         .inRoot(RootMatchers.isPlatformPopup())
         //       .perform(click());

    }

}
